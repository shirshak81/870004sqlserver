CREATE TABLE menuitems
(
	menu_id int primary key identity,
	menuname varchar(45) not null,
    price varchar(45) not null,
    active varchar(45) not null,
    date_of_launch datetime not null,
    category varchar(45) not null,
    freedelivery varchar(45) not null
)

create table userID(
	user_id int primary key identity,
    username varchar(45) not null,
    usertype varchar(45) not null
)

create table cart(
	cart_id int primary key identity,
    menu_id int not null,
    user_id int not null,
	foreign key (menu_id) references menuitems(menu_id),
    foreign key (user_id) references userID(user_id)
)
drop table menuitems