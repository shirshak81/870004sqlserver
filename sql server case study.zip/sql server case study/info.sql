
---- 1
INSERT INTO menuitems (menuname, price, active, date_of_launch, category, free_delivery)
VALUES ( 'Sandwich', 99.00, 'Yes', '2017-03-15', 'Main Course', 'Yes'),
	   ( 'Burger', 129.00, 'Yes', '2017-12-23', 'Main Course', 'No'),
	   ( 'Pizza', 149.00, 'Yes', '2018-08-21', 'Main Course', 'No'),
	   ( 'French Fries', 57.00, 'No', '2017-07-02', 'Starters', 'Yes'),
	   ( 'Chocolate Brownies', 32.00, 'Yes', '2022-11-02', 'Desserts', 'Yes')
SELECT * FROM menuitems
GO

---- 2
SELECT * FROM menuitems
WHERE date_of_launch > '01-09-2020' AND active = 'Yes'
GO

---- 3
--1
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'menuid_search')
	DROP PROC menuid_search
GO
CREATE PROCEDURE menuid_search(@emp_id int) AS
BEGIN
	SELECT * FROM menuitems
	WHERE menu_id = @emp_id
END

EXEC menuid_search 2

--2
BEGIN TRAN
UPDATE menuitems 
SET menuname = 'Chicken lollipop', category = 'Starter'
WHERE menu_id = '2'
SELECT * FROM menuitems
ROLLBACK TRAN
---- 4 
insert into userID(username, usertype)
values('Jade', 'Admin'), ('Max', 'customer'), ('brock', 'customer')
select * from userID

insert into cart(menu_id, user_id)
values(1,2),(2,2),(3,2),
	  (1,1),(2,1),(3,1)

select * from cart

---- 5
-- 1
IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'selectuser')
	DROP PROC selectuser
GO
CREATE PROC selectuser(@userId int) AS
BEGIN
	select m.* from menuitems m
	join cart c on c.menu_id = m.menu_id
	join userID u on c.user_id = u.user_id
	where u.user_id = @userId
END

EXEC select_user 2

-- 2
	select SUM(CAST(m.price AS float)) from menuitems m
	join cart c on c.menu_id = m.menu_id
	join userID u on c.user_id = u.user_id
	where u.user_id = 2

----6
begin tran
delete c from cart c
	join userID u on c.user_id = u.user_id
	where u.user_id = 2
select * from cart
rollback tran